// 1. Invocamos a Express
const express = require('express');
const path = require('path'); // Importar path para manejar rutas de archivos
const app = express();

// 2. Seteamos urlencoded para captar los datos de un formulario
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// 3. Invocamos a dotenv para las variables de entorno
const dotenv = require('dotenv');
dotenv.config({ path: './env/.env' });

// 4. Configuración del directorio público para archivos estáticos
app.use('/resources', express.static(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));

// 5. Invocamos a bcryptjs para el hashing de contraseñas
const bcryptjs = require('bcryptjs');

// 6. Configuración de la variable de sesión
const session = require('express-session');
app.use(session({
    secret: 'secret', // Cambiar por una cadena más robusta en producción
    resave: true,
    saveUninitialized: true
}));

// 7. Invocamos al módulo de conexión de la base de datos
const connection = require('./database/db');

// **Ruta para el formulario de login**
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html')); // Envía el archivo login.html
});

// 8. Establecemos las rutas
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html')); // Envía el archivo index.html
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'register.html')); // Envía el archivo register.html
});

app.get('/dashboardAdmin', (req, res) => {
    if (req.session.loggedin) {
        res.sendFile(path.join(__dirname, 'dashboardAdmin.html')); // Envía el archivo dashboardAdmin.html
    } else {
        res.redirect('/login'); // Redirige al login si no está autenticado
    }
});

// 9. Registro de usuario
app.post('/register', async (req, res) => {
    const usuario = req.body.usuario;
    const password = req.body.password;
    const rol = req.body.rol;

    // Hashear contraseña
    let passwordHash = await bcryptjs.hash(password, 8);

    connection.query('INSERT INTO usuario SET ?', { usuario: usuario, password: passwordHash, rol_idRol: rol }, async (error, results) => {
        if (error) {
            console.log(error);
        } else {
            res.redirect('/register'); // Redirige a la página de registro después de registrar el usuario
        }
    });
});

// 10. Autenticación de usuario
app.post('/auth', async (req, res) => {
    const usuario = req.body.usuario;
    const password = req.body.password;

    if (usuario && password) {
        connection.query('SELECT * FROM usuario WHERE usuario = ?', [usuario], async (error, results) => {
            if (results.length == 0 || !(await bcryptjs.compare(password, results[0].password))) {
                res.redirect('/login'); // Redirige al login si las credenciales son incorrectas
            } else {
                req.session.loggedin = true;
                req.session.usuario = results[0].usuario;
                res.redirect('/dashboardAdmin'); // Redirige al dashboard después de un login exitoso
            }
        });
    } else {
        res.send('Por favor ingrese un usuario y/o password');
    }
});

// 11. Autenticación de acceso a páginas protegidas
app.get('/dashboard', (req, res) => {
    if (req.session.loggedin) {
        res.sendFile(path.join(__dirname, 'dashboard.html')); // Envía el archivo dashboard.html si está autenticado
    } else {
        res.redirect('/login'); // Redirige al login si no está autenticado
    }
});

// 12. CRUD para tablas de usuario y empleado

// Usuarios
app.get('/usuario', (req, res) => {
    connection.query('SELECT * FROM usuario', (error, results) => {
        if (error) {
            throw error;
        } else {
            res.json(results); // Enviar la lista de usuarios como JSON
        }
    });
});

// Ruta API para obtener la lista de usuarios
app.get('/api/usuarios', (req, res) => {
    connection.query('SELECT * FROM usuario', (error, results) => {
        if (error) {
            return res.status(500).json({ error: error.message });
        }
        res.json(results);
    });
});

// Nuevo Usuario
app.post('/usuario/add', async (req, res) => {
    const { username, rol, password } = req.body;

    if (!username) {
        return res.status(400).json({ message: 'El nombre de usuario es obligatorio' });
    }

    const hashedPassword = await bcryptjs.hash(password, 8);

    connection.query('INSERT INTO usuario SET ?', 
    { usuario: username, rol_idRol: rol, password: hashedPassword }, 
    (error, results) => {
        if (error) {
            throw error;
        } else {
            res.json({ message: 'Usuario agregado exitosamente' });
        }
    });
});

// Ruta para obtener todos los usuarios
app.get('/usuario', (req, res) => {
    connection.query('SELECT * FROM usuario', (error, results) => {
        if (error) {
            throw error;
        } else {
            res.json(results); // Enviar la lista de usuarios como JSON
        }
    });
});

app.get('/api/usuarios', (req, res) => {
    connection.query('SELECT * FROM usuario', (error, results) => {
        if (error) {
            return res.status(500).json({ error: error.message });
        }
        res.json(results);
    });
});


// Ruta para agregar un nuevo usuario
app.post('/usuario/add', async (req, res) => {
    const { username, rol, password } = req.body;

    if (!username) {
        return res.status(400).json({ message: 'El nombre de usuario es obligatorio' });
    }

    const hashedPassword = await bcryptjs.hash(password, 8);

    connection.query('INSERT INTO usuario SET ?', 
    { usuario: username, rol_idRol: rol, password: hashedPassword }, 
    (error, results) => {
        if (error) {
            throw error;
        } else {
            res.json({ message: 'Usuario agregado exitosamente' });
        }
    });
});

// Ruta para obtener un usuario específico
app.get('/usuario/:id', (req, res) => {
    const userId = req.params.id;
    connection.query('SELECT * FROM usuario WHERE idUsuario = ?', [userId], (error, result) => {
        if (error) throw error;
        res.json(result[0]);
    });
});

// Ruta para actualizar un usuario
app.put('/usuario/update/:id', (req, res) => {
    const userId = req.params.id;
    const { username, rol } = req.body;
    connection.query('UPDATE usuario SET usuario = ?, rol_idRol = ? WHERE idUsuario = ?', [username, rol, userId], (error, result) => {
        if (error) throw error;
        res.json({ message: 'Usuario actualizado correctamente' });
    });
});

// Ruta para eliminar un usuario
app.delete('/usuario/delete/:id', (req, res) => {
    const userId = req.params.id;
    connection.query('DELETE FROM usuario WHERE idUsuario = ?', [userId], (error, result) => {
        if (error) throw error;
        res.json({ message: 'Usuario eliminado correctamente' });
    });
});


// Empleados
app.get('/empleado', (req, res) => {
    connection.query('SELECT * FROM empleado', (error, results) => {
        if (error) {
            throw error;
        } else {
            res.send(results); // Devuelve los resultados en formato JSON, ajusta según sea necesario
        }
    });
});

// Editar empleado
app.get('/empleadoEdit/:idEmpleado', (req, res) => {
    const idEmpleado = req.params.idEmpleado;

    connection.query('SELECT * FROM empleado WHERE idEmpleado=?', [idEmpleado], (error, results) => {
        if (error) {
            throw error;
        } else {
            res.send(results[0]); // Devuelve los detalles del empleado en formato JSON, ajusta según sea necesario
        }
    });
});

// Crear empleado
app.get('/empleadoCreate', (req, res) => {
    res.sendFile(path.join(__dirname, 'empleadoCreate.html')); // Envía el archivo empleadoCreate.html
});

app.post('/registrar2', async (req, res) => {
    const { usuario, password } = req.body;
    const rol_idRol = 1; // Valor fijo de 1

    try {
        // Hash de la contraseña antes de almacenarla
        const hashedPassword = await bcryptjs.hash(password, 10);

        // Insertar los datos en la base de datos
        const sql = 'INSERT INTO usuario (usuario, password, rol_idRol) VALUES (?, ?, ?)';
        const values = [usuario, hashedPassword, rol_idRol];

        connection.query(sql, values, (err, result) => {
            if (err) {
                console.error('Error al registrar el usuario: ' + err.message);
                res.status(500).send('Error al registrar el usuario');
            } else {
                console.log('Usuario registrado con éxito');

                connection.query('SELECT MAX(idUsuario) AS ultimoID FROM usuario', (error, results) => {
                    if (error) {
                        throw error;
                    } else {
                        if (results.length > 0) {
                            const ultimoID = results[0].ultimoID;
                            console.log(`El último ID de usuario registrado es: ${ultimoID}`);

                            const cui = req.body.cui;
                            const nombre = req.body.nombre;
                            const apellido = req.body.apellido;
                            const fechaNac = req.body.fechaNac;
                            const telefono = req.body.telefono;
                            const direccion = req.body.direccion;
                            const puesto = req.body.puesto;
                            const email = req.body.email;
                            const nit = req.body.nit;

                            connection.query('INSERT INTO empleado SET ?', {
                                cui: cui,
                                nombre: nombre,
                                apellido: apellido,
                                fechaNac: fechaNac,
                                telefono: telefono,
                                direccion: direccion,
                                puesto: puesto,
                                email: email,
                                nit: nit,
                                usuario_idUsuario: ultimoID
                            }, (error, results) => {
                                if (error) {
                                    console.log(error);
                                } else {
                                    res.redirect('/empleado'); // Redirige a la lista de empleados después de crear uno
                                }
                            });
                        }
                    }
                });
            }
        });
    } catch (err) {
        console.error('Error al encriptar la contraseña: ' + err.message);
        res.status(500).send('Error al encriptar la contraseña');
    }
});

// Eliminar empleado y usuario asociado
app.get('/empleadoDelete/:idEmpleado', (req, res) => {
    const idEmpleado = req.params.idEmpleado;

    connection.query('SELECT usuario_idUsuario FROM empleado WHERE idEmpleado = ?', [idEmpleado], (error, results) => {
        if (error) {
            console.log(error);
            res.status(500).send('Error al obtener el usuario asociado al empleado');
            return;
        }

        const usuario_idUsuario = results[0].usuario_idUsuario;

        connection.query('DELETE FROM empleado WHERE idEmpleado = ?', [idEmpleado], (error, empleadoResult) => {
            if (error) {
                console.log(error);
                res.status(500).send('Error al eliminar empleado');
                return;
            }

            connection.query('DELETE FROM usuario WHERE idUsuario = ?', [usuario_idUsuario], (error, usuarioResult) => {
                if (error) {
                    console.log(error);
                    res.status(500).send('Error al eliminar usuario asociado al empleado');
                    return;
                }

                res.redirect('/empleado'); // Redirige a la lista de empleados después de eliminar uno
            });
        });
    });
});

// 13. Importar funciones de CRUD desde un controlador
const empleCrud = require('./controllers/empleadoCrud');
app.post('/updateEmpleado', empleCrud.updateEmpleado);

// 14. Función para limpiar la caché luego del logout
app.use(function (req, res, next) {
    if (!req.usuario)
        res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});

// 15. Logout
app.get('/logout', function (req, res) {
    req.session.destroy(() => {
        res.redirect('/login'); // Siempre se ejecutará después de que se destruya la sesión
    });
});

// 16. Inicializar el servidor
app.listen(3000, () => {
    console.log('SERVER RUNNING IN http://localhost:3000');
});