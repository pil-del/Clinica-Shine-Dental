const bcryptjs = require('bcryptjs');
const mysql = require('mysql');
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'clinica_dental'
});

db.connect(err => {
    if (err) throw err;
    console.log('Conectado a la base de datos');

    db.query('SELECT * FROM usuario', async (error, results) => {
        if (error) throw error;

        for (const user of results) {
            if (!await bcryptjs.compare(user.password, '$2a$10$e5EFOgH39gTDP/Dm5/a8KOaG9.b6OXk4XKjNeUqVBFWg.IQ9KlVZ2')) { // Reemplaza el hash de prueba si es necesario
                let passwordHash = await bcryptjs.hash(user.password, 8);
                db.query('UPDATE usuario SET password = ? WHERE idusuario = ?', [passwordHash, user.idusuario], (err) => {
                    if (err) throw err;
                    console.log(`Contraseña del usuario ${user.user} actualizada`);
                });
            }
        }
        db.end();
    });
});
